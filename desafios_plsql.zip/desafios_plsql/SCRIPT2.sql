SET serveroutput ON
DECLARE
    v_datacadastro DATE := to_date('30-dez-2019'); --
    v_idnf NUMBER := 0;
    v_iditemnf NUMBER := 0;
BEGIN
    DBMS_OUTPUT.PUT_LINE('Iniciando bloco');
    FOR v_loop IN 0..999 LOOP
        IF (mod(v_loop,100) = 0) THEN
            v_datacadastro := v_datacadastro + interval '1' day;        
        END IF;
        
        v_idnf := v_loop + 1;
        
        INSERT INTO exame_nf (idnf, numero, datacadastro) VALUES (v_idnf, v_idnf, TO_DATE(v_datacadastro, 'dd/mm/yy'));
        
        SELECT NVL(MAX(IDITEMNF), 0) INTO v_iditemnf FROM exame_itemnf;
        
        FOR v_loop2 IN 0..2 LOOP
            v_iditemnf := v_iditemnf + 1;
            INSERT INTO exame_itemnf (iditemnf, idnf, idproduto, qtde) VALUES (v_iditemnf, v_idnf, v_iditemnf, 2);
        END LOOP;
        
    END LOOP;
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Finalizando bloco');
END;