CREATE OR REPLACE PROCEDURE sp_DEFINIR_VALORES IS
    v_valor NUMBER := 0;
    v_totalgeral NUMBER := 0;
    
    CURSOR c_exame_itemnf IS SELECT iditemnf, idnf, qtde FROM exame_itemnf;
BEGIN
    DBMS_OUTPUT.PUT_LINE('Iniciando sp_DEFINIR_VALORES');
    UPDATE exame_nf SET totalgeral = NULL; -- Update realizado para n�o gerar inconsist�ncia, caso necess�rio comentar a linha
    FOR item IN c_exame_itemnf LOOP
    
        v_valor := floor(dbms_random.value(1, 100));
        
        UPDATE exame_itemnf SET valor = v_valor WHERE iditemnf = item.iditemnf;
        
        SELECT NVL(totalgeral, 0) INTO v_totalgeral FROM exame_nf WHERE idnf = item.idnf;
        v_totalgeral := v_totalgeral + (item.qtde * v_valor);
        
        UPDATE exame_nf SET totalgeral = v_totalgeral WHERE idnf = item.idnf;
        
    END LOOP;
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Finalizando sp_DEFINIR_VALORES');
EXCEPTION
    WHEN OTHERS THEN ROLLBACK;
END sp_DEFINIR_VALORES;

EXECUTE sp_DEFINIR_VALORES;