CREATE INDEX ix_valor ON exame_itemnf (valor);

CREATE VIEW v_total_exame_nf_datacadastro AS
    SELECT datacadastro, COUNT(idnf)AS "COUNT"
    FROM exame_nf
    WHERE idnf IN (SELECT idnf
                    FROM exame_itemnf
                    WHERE valor < 50)
    GROUP BY datacadastro
    ORDER BY datacadastro;
    
SELECT * FROM V_TOTAL_EXAME_NF_DATACADASTRO;