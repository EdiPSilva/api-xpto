SELECT datacadastro, COUNT(idnf)
FROM exame_nf
WHERE idnf IN (SELECT idnf FROM exame_itemnf WHERE valor < 50)
GROUP BY datacadastro
ORDER BY datacadastro;